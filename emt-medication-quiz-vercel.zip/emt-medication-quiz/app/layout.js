import "./globals.css";
export const metadata = { title: "EMT Medication Quiz", description: "Medication dosage practice" };
export default function RootLayout({children}) { return <html lang="en"><body>{children}</body></html>; }