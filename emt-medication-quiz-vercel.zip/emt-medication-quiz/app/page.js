'use client';
import {useMemo,useState} from 'react';

const MEDS=[
{name:"Amiodarone",ind:"Cardiac arrest / shockable rhythm",answer:["2 ampoules","6 mL"],q:"Amiodarone: ___ ampoules = ___ mL"},
{name:"Atropine",ind:"Bradycardia",answer:["1 mL"],q:"Atropine: ___ mL"},
{name:"Adrenaline (IM)",ind:"Anaphylaxis",answer:["0.3 mL"],q:"Adrenaline (adult, IM): ___ mL"},
{name:"Ventolin + NS (Adult)",ind:"Asthma / bronchospasm",answer:["2:2"],q:"Ventolin + NS (adult): ___ : ___"},
{name:"Ventolin + NS (Paeds)",ind:"Asthma / bronchospasm",answer:["1:3"],q:"Ventolin + NS (paeds): ___ : ___"},
{name:"Synthocinon",ind:"Maternity / pregnancy cases",answer:["1 mL","IM @ thigh"],q:"Synthocinon: ___ mL, ___"},
{name:"Tramadol",ind:"Painkiller / analgesia",answer:["0.5 mL","1 ampoule"],q:"Tramadol: ___ mL = ___ ampoule"},
{name:"TXA",ind:"Stops bleeding / haemorrhage",answer:["2 ampoules","100 mL NS","4 drops/sec"],q:"TXA: ___ ampoules + ___ mL NS → ___ drops/sec"},
{name:"Honey sachet",ind:"Hypoglycaemia — able to swallow",answer:["20 g"],q:"Honey sachet: ___ g"},
{name:"Dextrose",ind:"Hypoglycaemia — unable to swallow",answer:["500 mL"],q:"Dextrose: ___ mL"}
];

const norm=s=>s.toLowerCase().replace(/\s+/g,'').replace(/,/g,'.').replace(/ampulses?/g,'ampoules').replace(/ampules?/g,'ampoule');

function makePrompt(m){
 return m.q.replace(/___/g,()=>`<input/>`);
}

export default function Home(){
 const [mode,setMode]=useState("all"),[order,setOrder]=useState(MEDS.map((_,i)=>i)),[i,setI]=useState(0),[answers,setAnswers]=useState([]),[score,setScore]=useState(0),[done,setDone]=useState(false),[input,setInput]=useState([]);
 const m=MEDS[order[i]];
 const shuffled=useMemo(()=>order,[order]);

 function start(type="all"){
   let arr=MEDS.map((_,x)=>x);
   if(type==="wrong") arr=answers.filter(x=>!x.correct).map(x=>x.idx);
   arr.sort(()=>Math.random()-.5);
   setMode(type);setOrder(arr);setI(0);setScore(0);setDone(false);setInput([]);
 }
 function submit(){
   const got=input.map(x=>norm(x||""));
   const ok=m.answer.every((a,k)=>got[k]===norm(a));
   const rec={idx:order[i],correct:ok};
   setAnswers(prev=>[...prev.filter(x=>x.idx!==order[i]),rec]);
   if(ok)setScore(s=>s+1);
   if(i===order.length-1)setDone(true); else {setI(x=>x+1);setInput([]);}
 }
 if(done) return <main><section className="card center"><div className="badge">ROUND COMPLETE</div><h1>{score}/{order.length}</h1><p className="big">{score===order.length?"Perfect. 🔥":"Keep drilling the weak spots."}</p><button onClick={()=>start("all")}>Retest Everything</button>{answers.some(x=>!x.correct)&&<button className="secondary" onClick={()=>start("wrong")}>Retest Wrong</button>}<p className="note">Study aid only. Verify medication doses and protocols against your current SCDF training materials.</p></section></main>;

 const blanks=(m.q.match(/___/g)||[]).length;
 return <main><header><div><span className="eyebrow">SCDF EMT</span><h1>Medication Quiz</h1></div><div className="score">{score}/{order.length}</div></header>
 <section className="card"><div className="progress"><span style={{width:`${((i)/order.length)*100}%`}}/></div><p className="counter">Question {i+1} of {order.length}</p><h2>{m.name}</h2><p className="ind">{m.ind}</p><div className="question">{m.q.split("___").map((part,k)=><span key={k}>{part}{k<blanks&&<input autoFocus={k===0} value={input[k]||""} onChange={e=>setInput(a=>{let n=[...a];n[k]=e.target.value;return n})} onKeyDown={e=>e.key==="Enter"&&submit()}/>}</span>)}</div><button onClick={submit}>Check Answer</button><p className="hint">Type the dosage exactly enough to match the expected answer.</p></section>
 <nav><button className="secondary" onClick={()=>start("all")}>Shuffle All</button>{answers.some(x=>!x.correct)&&<button className="secondary" onClick={()=>start("wrong")}>Retest Wrong</button>}</nav>
 </main>
}
