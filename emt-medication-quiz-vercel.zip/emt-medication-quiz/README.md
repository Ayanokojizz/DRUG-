# EMT Medication Quiz

Mobile-first Next.js quiz for the medication list supplied in ChatGPT.

## Run locally
npm install
npm run dev

## Deploy to Vercel
1. Push this folder to GitHub.
2. Import the repository in Vercel.
3. Framework: Next.js (auto-detected).
4. Deploy.

The quiz supports shuffled rounds, fill-in-the-blank dosage questions, scoring, Retest Everything, and Retest Wrong.

Important: this is a study aid. Verify all medication doses, routes, dilution and administration instructions against your current SCDF training materials/protocols before using them operationally.
